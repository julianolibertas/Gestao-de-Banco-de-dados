import sqlite3
from sqlite3 import Error

DB_FILE = 'biblioteca.db'

#criar tabelas
sql_editora = """ 
  CREATE TABLE IF NOT EXISTS tbl_editora (
	ideditora integer PRIMARY KEY AUTOINCREMENT,
	nomeeditora varchar(50) NOT NULL
  );
"""

def conectar():
  """
  Função para conectar ao banco de dados SQLite.
  Retorna um objeto de conexão (conn) ou None se a conexão falhar.
  """
  try: 
    conn = sqlite3.connect(DB_FILE)

    conn.execute(sql_editora)
    conn.commit()

    print("Conexão com o banco de dados 'biblioteca.db' bem-sucedida!")
    return conn
  except Error as e:
    print(f"Erro ao conectar ao banco de dados: {e}")
    return None

# Um pequeno teste (opcional) para verificar se o módulo está funcionando
if __name__ == '__main__':
  conn=conectar()
  if conn:
    print("Conexão bem-sucedida!")
    conn.close()
  else:
    print("Falha na conexão")

# conectar() # testar se esta funcionando.
