from database import conectar

# -- CREATE (inserir) --
def criar_editora(nome):
  """Insere uma nova editora na tbl_editora"""
  conn = conectar() # obtém um nova conexão
  if conn is None:
    return #Se a conexão falhou, não faz nada.

  try:
    
    cursor = conn.cursor()
    # SQL parametrizado para evitar SQL Injection
    sql = "INSERT INTO tbl_editora(nomeeditora) VALUES(?) returning ideditora"

    # Executa o comando. Passamos os valores como uma tupla
    cursor.execute(sql, (nome,))

    # Pega o ID da editora que acabamos de inserir
    id_nova_editora = cursor.fetchone()[0]

    # Confirma a transação
    conn.commit()

    print(f"Editora '{nome}' inserida com sucesso!(ID: {id_nova_editora}).")

  except Exception as e:
    # Se der erro, desfaz a transação
    conn.rollback()
    print(f"Erro ao inserir editora: {e}")
  finally:
    # Fecha a conexão, independentemente de sucesso ou falha
    conn.close()

# -- READ (Listar/Ler)
def listar_editoras():
  """lista todos os editora cadastradas"""
  conn = conectar()
  if conn is None:
    return

  try:
    cursor = conn.cursor()
    # Comando SQL simples para selecionar
    cursor.execute("SELECT ideditora, nomeeditora from tbl_editora ORDER BY nomeeditora ")

    # Pega todos os resultados da consulta
    editoras = cursor.fetchall()

    if not editoras:
      print("Nenhuma editora encontrada.")
      return

    print("\n--- Lista de Editoras ---")
      # Itera sobre os resultados (lista de tuplas) e imprime
    for editora in editoras:
      # editora[0] é ideditora, editora[1] é nomeeditora
      print(f"ID: {editora[0]}, Nome: {editora[1]}")

  except Exception as e:
    print(f"Erro ao listar editoras: {e}")

  finally:
    conn.close()

# --- Update (atualizar) ---
def atualizar_editora(id_editora, novo_nome):
  """"Atualiza o nome de uma editora existente"""
  conn = conectar()
  if conn is None:
    return

  try:
    cursor = conn.cursor()
    sql = "UPDATE tbl_editora SET nomeeditora = ? WHERE ideditora = ?"

    # A ordem dos parâmetros na tupla (novo_nome, id_editora)
    # deve bater com a ordem dos ? no SQL
    cursor.execute(sql, (novo_nome, id_editora))

    # cursor.rowcount diz quantas linhas foram afetadas pelo comando
    if cursor.rowcount == 0:
      print(f"Nenhuma editora encontrada com ID {id_editora}. Nada foi atualizado.")
    else:
      # Se afetou alguma linha, commita
      conn.commit()
      print(f"Editora ID {id_editora} atualizada para '{novo_nome}'.")

  except Exception as e:
    conn.rollback()
    print(f"Erro ao atualizar editora: {e}")

  finally:
    conn.close()

# --- DELETE (Excluir) ---
def excluir_editora(id_editora):
  """Excluir uma editora pelo seu ID."""
  conn = conectar()
  if conn is None:
    return

  try:
    cursor = conn.cursor()
    sql = "DELETE FROM tbl_editora WHERE ideditora = ?"
    cursor.execute(sql, (id_editora,))

    if cursor.rowcount == 0:
      print(f"Nenhuma editora encontrada com ID {id_editora}. Nada foi excluida.")
    else:
      conn.commit()
      print(f"Editora ID {id_editora} excluida com sucesso.")

  except Exception as e:
    conn.rollback()
    print(f"Erro ao excluir editora: {e}")
    # Explicação didática importante:
    print("Nota: Se esta editora estiver sendo usada por um livro na 'tbl_livro',")
    print("o SQLite irá bloquear a exclusão (Erro de Chave Estrangeira),")
    print("mesmo que seu SQL tenha 'ON DELETE CASCADE' (isso se aplica à tbl_livro,")
    print("não à tbl_editora sendo referenciada).")

  finally:
    conn.close()


# --- Menu Principal da Aplicação ---
def menu():
  """Exibe o menu de opções para o usuário"""
  while True:
    print("\n--- CRUD de Editoras (Biblioteca) ---")
    print("1. Listar Editoras")
    print("2. Adicionar Nova Editora")
    print("3. Atualizar Editora")
    print("4. Excluir Editora")
    print("5. Sair")

    opcao = input("Escolha uma opção: ")

    if opcao == "1":
      # READ
      listar_editoras()
    elif opcao == "2":
      # CREATE
      nome = input("Digite o nome da nova editora: ")
      if nome.strip(): # Verifica se o nome não esta vazio
        criar_editora(nome)
      else:
        print("O nome não pode ser vazio.")
    elif opcao == "3":
      #UPDATE
      try:
        id_ed = int(input("Digite o ID da editora para atualizar: "))
        novo_nome = input(f"Digite o novo nome para a editora {id_ed}: ")
        if novo_nome.strip():
          atualizar_editora(id_ed, novo_nome)
        else:
          print("O nome não pode ser vazio.")
      except ValueError:
        print("ID Inválido. Por favor, digite um número.")
    elif opcao == "4":
      #DELETE
      try:
        id_ed = int(input("Digite o ID da editora para excluir: "))
        # confirmação de segurança
        confirm = input(f"Tem certeza que deseja excluir a editora {id_ed} (s/n)").lower()
        if confirm == "s":
          excluir_editora(id_ed)
        else:
          print("Exclusão cancelada")
      except ValueError:
        print("ID inválido. Por favor digite um numero.")

    elif opcao == "5":
      print("Saindo do programa.")
      break # Quebra o loop 'while True'
    else:
      print("Opção inválida. Tente novamente.")

# Ponto de entrada do script
# O código dentro deste 'if' só roda quando executamos este arquivo diretamente
if __name__ == "__main__":
  menu()










