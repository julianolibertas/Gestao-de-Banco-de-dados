Avaliação de gestão de Banco de dados. 23/09/2024

Faça o download da avaliação no github:
https://github.com/julianolibertas/Gestao-de-Banco-de-dados
arquivo: Avaliacao_gestaoBD_outubro2025.zip

Após o término desta avaliação, insira todos os comandos sql em um arquivo texto. Ex. avaliacao.sql

- Crie um banco de dados com o nome: rh
- Crie um usuário com todos os privilégios para abrir apenas o banco de dados rh
    nome: rhuser, senha: Libert@s
- Conceda todas as permissões necessárias ao rhuser para ter controle total sobre banco de dados;
- Abra o banco de dados rh com o rhuser.
- Insira as tabelas abaixo:

CREATE TABLE departamentos (
  id_departamento SERIAL PRIMARY KEY, 
  nome_departamento VARCHAR(50) NOT NULL
);

CREATE TABLE cargos (
  id_cargo VARCHAR(20) PRIMARY KEY,
  nome_cargo VARCHAR(50) NOT NULL
);

CREATE TABLE funcionarios (
  id_funcionario SERIAL PRIMARY KEY, 
  nome VARCHAR(50) NOT NULL,
  sobrenome VARCHAR(50) NOT NULL,
  data_nascimento DATE,
  id_cargo VARCHAR(20),
  id_departamento INT,
  salario DECIMAL(10,2)
);

CREATE TABLE treinamentos (
  id_treinamento SERIAL PRIMARY KEY, 
  nome_treinamento VARCHAR(100) NOT NULL,
  data_inicio DATE,
  data_fim DATE,
  carga_horaria INT,
  trei_local VARCHAR(100),
  ministrante VARCHAR(100),
  id_funcionario INT
);

- Crie as chaves estrangeiras onde for necessárias.
  obs: (foreign key), (update: no action e delete: restrict)

- Popule as tabelas importando os arquivos CSVs.
-  Insira mais 2 registros na tabela funcionários, coloque seus dados pessoais e crie um fictício.  
    Obs: no campo id_departamento, coloque um registro no Markenting e o outro no financeiro.


- Insira dados abaixo para popular a tabela treinamentos.
INSERT INTO treinamentos (nome_treinamento, data_inicio, data_fim, carga_horaria, trei_local, ministrante, id_funcionario)
VALUES
  ('Introdução ao SQL', '2025-07-01', '2025-07-05', 20, 'Sala de treinamento', 'João Silva', 1),
  ('Gestão de Projetos', '2025-08-15', '2025-08-20', 30, 'Auditório', 'Maria Santos', 2),
  ('Desenvolvimento Web', '2025-09-10', '2025-09-25', 40, 'Laboratório', 'Pedro Almeida', 3);

- Adicione 2 registros, crie novos cursos com data futura na tabela de treinamentos. Use os 2 funcionários que vc criou.
- Listar todos os registros de cargos, departamentos, funcionários e treinamentos.
- Listar nome, sobrenome, nome do cargo, nome do departamento e salário.
- Listar apenas os funcionários 1,3 e o registro que esta no seu nome.
- Apague o registro fictício que você criou.
- Listar o maior e o menor salário.
- Listar nome e sobrenome concatenados (numa coluna só) e o salário. 
- Listar todos os funcionários do departamento de Tecnologia da Informação:
- Calcular a média salarial
- Listar quantos dias faltam para o Natal.
- Crie uma view
- Crie uma função

- Fazer backup do banco de dados (estrutura e dados).
   Navegador de banco de dados (lado esquerdo)
   1. Clique com o botão direito no BD rh.
   2. Vá em ferramentas/Backup.
   3. Escolha o formato PLAIN.
   4. Defina o diretório de saída e o nome do arquivo.
   5. Clique em "Iniciar".
- Compacte o arquivo de backup, mais o arquivo texto com todos os comandos e envie para o portal do aluno.




